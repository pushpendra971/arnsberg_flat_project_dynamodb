//******************************************************************************************************************************************* /

///// ...................................... start default setup ............................................////
let mode, docClient, S3;
const AWS = require('aws-sdk');
const response = require('./lib/response.js');
const database = require('./lib/database.js');
// console.log(process.env.AWS_REGION);
if (process.env.AWS_REGION == "local") {
	mode = "offline";
	docClient = require('../../../offline/dynamodb').docClient;
} else {
	mode = "online";
	docClient = new AWS.DynamoDB.DocumentClient({});
}
///// ...................................... end default setup ............................................////

// modules defined here
const Ajv = require('ajv');
const setupAsync = require('ajv-async');
const ajv = setupAsync(new Ajv);

//schema for the get Flats
const getSchema = {
	"$async": true,
	"type": "object",
	"additionalProperties": false,

	"properties":
	{
		"active": {
			"type": "string",
			"enum": [
				"true",
				"false",
				"TRUE",
				"FALSE",
				"True",
				"False"
			]
		},
		"floor": {
			"type": "string",

		},
		"flattype": {
			"type": "string",
		},
		"flat_status": {
			"type": "string",
			"enum": [
				"available",
				"reserved",
				"sold",
				"Available",
				"Sold",
				"Reserved",
				"AVAILABLE",
				"RESERVED",
				"SOLD"
			]
		},
		"priceSort": {
			"type": "string"
		},
		"features": {
			"type": "string",
		},
		"lastEvaluatedKeyid": {
			"type": "string"
		},
		"lastEvaluatedKeyprice": {
			"type": "string"
		},
		"lastEvaluatedKeyactive": {
			"type": "string"
		}
	}
};
const validate = ajv.compile(getSchema);

module.exports = { execute };

/**
 * This is the Promise caller which will call each and every function based
 * @param  {[type]}   data     [content to manipulate the data]
 * @param  {Function} callback [need to send response with]
 * @return {[type]}            [description]
 */


function execute(data, callback) {
	validate_all(validate, data)
		.then(function (result) {
			return getFlats(result);
		})
		.then(function (result) {
			response({ code: 200, body: result }, callback);
		})
		.catch(function (err) {
			response({ code: 400, err: { err } }, callback);
		})
}

/**
 * validate the data to the categories
 * @param  {[type]} data [description]
 * @return {[type]}      [description]
 */
function validate_all(validate, data) {
	return new Promise((resolve, reject) => {
		validate(data).then(function (res) {
			console.log(res);
			resolve(res);
		}).catch(function (err) {
			console.log(JSON.stringify(err, null, 6));
			reject(err.errors[0].dataPath + " " + err.errors[0].message);
		})
	})
}
var offset = 10;//limit

function getFlats(data) {
	console.log(database);
	var params = {
		TableName: database.Table[0].TableName, //table name : FLATS
		IndexName: database.Table[0].IndexName  //index name : priceSort
	};

	//Querry for getting flats   

    // get by hash key active
	if (data.active) {
		params["KeyConditionExpression"] = "#active = :active";
		params["ExpressionAttributeValues"] = { ":active": (data.active) };
		params["ExpressionAttributeNames"] = { "#active": "active" };

		//get by floor
		if (data.floor) {
			if (data.floor.length == 1) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floor IN (:floor)";
				params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor);
				params["ExpressionAttributeNames"]["#floor"] = "floor";
			}
			//search by multiple(2) floors
			if (data.floor.length == 3) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floor IN (:floor,:flor)";
				params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor.substring(0, 1));
				params["ExpressionAttributeValues"][":flor"] = parseInt(data.floor.substring(2, 3));
				params["ExpressionAttributeNames"]["#floor"] = "floor";
			}
			//search by multiple(3) floors
			if (data.floor.length == 5) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floor IN (:floor,:flor,:flr)";
				params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor.substring(0, 1));
				params["ExpressionAttributeValues"][":flor"] = parseInt(data.floor.substring(2, 3));
				params["ExpressionAttributeValues"][":flr"] = parseInt(data.floor.substring(4, 5));
				params["ExpressionAttributeNames"]["#floor"] = "floor";
			}

			//search by multiple(4) floors
			if (data.floor.length == 7) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floor IN (:floor,:flor,:flr,:fl)";
				params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor.substring(0, 1));
				params["ExpressionAttributeValues"][":flor"] = parseInt(data.floor.substring(2, 3));
				params["ExpressionAttributeValues"][":flr"] = parseInt(data.floor.substring(4, 5));
				params["ExpressionAttributeValues"][":fl"] = parseInt(data.floor.substring(6, 7));
				params["ExpressionAttributeNames"]["#floor"] = "floor";
			}

			//search by multiple(5) floors
			if (data.floor.length == 9) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floor IN (:floor,:flor,:flr,:fl,:f)";
				params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor.substring(0, 1));
				params["ExpressionAttributeValues"][":flor"] = parseInt(data.floor.substring(2, 3));
				params["ExpressionAttributeValues"][":flr"] = parseInt(data.floor.substring(4, 5));
				params["ExpressionAttributeValues"][":fl"] = parseInt(data.floor.substring(6, 7));
				params["ExpressionAttributeValues"][":f"] = parseInt(data.floor.substring(8, 9));
				params["ExpressionAttributeNames"]["#floor"] = "floor";
			}
		}

		// get flats by their flatTypes
		if (data.flattype) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			} else {
				params['FilterExpression'] += " and ";
			}
			params["FilterExpression"] += " #flattype =(:flattype)";
			params["ExpressionAttributeValues"][":flattype"] = parseInt(data.flattype);
			params["ExpressionAttributeNames"]["#flattype"] = "flattype";
		}

		//get flats by their flat_status
		if (data.flat_status) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			}
			else {
				params['FilterExpression'] += " and ";
			}
			params["FilterExpression"] += " #flat_status =(:flat_status)";
			params["ExpressionAttributeValues"][":flat_status"] = data.flat_status;
			params["ExpressionAttributeNames"]["#flat_status"] = "flat_status";
		}

		//get by feature_name
		if (data.features) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			}
			else {
				params['FilterExpression'] += " and ";
			}
			params["FilterExpression"] += "contains(#features,:features)";
			params["ExpressionAttributeValues"][":features"] = data.features;
			params["ExpressionAttributeNames"]["#features"] = "features";
		}

		//sort flats according to their price ascending or descending 
		if ((data.priceSort) == "true") {
			params['ScanIndexForward'] = true;
		} else {
			params['ScanIndexForward'] = false;
		}
		return new Promise((resolve, reject) => {
			//limit
			params['Limit'] = offset;
			//pagination
			if (data.lastEvaluatedKeyflatId && data.lastEvaluatedKeyactive && data.lastEvaluatedKeytotalPrice) {
				try {
					params['ExclusiveStartKey'] = {
						active: data.lastEvaluatedKeyactive,
						flatId: data.lastEvaluatedKeyflatId,
						totalPrice: parseFloat(data.lastEvaluatedKeytotalPrice)
					};
				} catch (error) {
					reject("Invalid last evaluated keys");
					return;
				}
			}
			console.log("get_data", params);
			docClient.query(params, function (err, data) {
				if (err) {
					reject(err);//error
				} else {
					console.log(data);
					var container = {};
					container['page'] = data.LastEvaluatedKey;
					container['data'] = data.Items;
					resolve(container);//get successful
				}
			});
		})
	} else {
		//scan flats from their fields
		if (data.floor || data.flattype || data.features || data.flat_status || (data.lastEvaluatedKeyflatId && data.lastEvaluatedKeyactive && data.lastEvaluatedKeytotalPrice)) {
			// get by floor 
			if (data.floor) {
				if (data.floor.length == 1) {
					console.log(data.floor.length);
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floor IN (:floor)";
					params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor);
					params["ExpressionAttributeNames"]["#floor"] = "floor";
				}
				if (data.floor.length == 3) {
					console.log(data.floor.length);
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floor IN (:floor,:flor)";
					params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor.substring(0, 1));
					params["ExpressionAttributeValues"][":flor"] = parseInt(data.floor.substring(2, 3));
					params["ExpressionAttributeNames"]["#floor"] = "floor";
				}
				if (data.floor.length == 5) {
					console.log(data.floor.length);
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floor IN (:floor,:flor,:flr)";
					params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor.substring(0, 1));
					params["ExpressionAttributeValues"][":flor"] = parseInt(data.floor.substring(2, 3));
					params["ExpressionAttributeValues"][":flr"] = parseInt(data.floor.substring(4, 5));
					params["ExpressionAttributeNames"]["#floor"] = "floor";
				}
				if (data.floor.length == 7) {
					//console.log(data.floorNo.length);
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floor IN (:floor,:flor,:flr,:fl)";
					params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor.substring(0, 1));
					params["ExpressionAttributeValues"][":flor"] = parseInt(data.floor.substring(2, 3));
					params["ExpressionAttributeValues"][":flr"] = parseInt(data.floor.substring(4, 5));
					params["ExpressionAttributeValues"][":fl"] = parseInt(data.floor.substring(6, 7));
					params["ExpressionAttributeNames"]["#floor"] = "floor";
				}
				if (data.floor.length == 9) {
				
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floor IN (:floor,:flor,:flr,:fl,:f)";
					params["ExpressionAttributeValues"][":floor"] = parseInt(data.floor.substring(0, 1));
					params["ExpressionAttributeValues"][":flor"] = parseInt(data.floor.substring(2, 3));
					params["ExpressionAttributeValues"][":flr"] = parseInt(data.floor.substring(4, 5));
					params["ExpressionAttributeValues"][":fl"] = parseInt(data.floor.substring(6, 7));
					params["ExpressionAttributeValues"][":f"] = parseInt(data.floor.substring(8, 9));
					params["ExpressionAttributeNames"]["#floor"] = "floor";
				}
			}
			//get by flatType
			if (data.flattype) {
				if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
					params['FilterExpression'] = "";
					params['ExpressionAttributeValues'] = {};
					params['ExpressionAttributeNames'] = {};
				} else {
					params['FilterExpression'] += " and ";
				}
				params['FilterExpression'] += "#flattype IN (:flattype) "
				params['ExpressionAttributeValues'][":flattype"] = parseInt(data.flattype);
				params['ExpressionAttributeNames']["#flattype"] = "flattype";
			}

			//get by FeatureName
			if (data.features) {
				if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
					params['FilterExpression'] = "";
					params['ExpressionAttributeValues'] = {};
					params['ExpressionAttributeNames'] = {};
				} else {
					params['FilterExpression'] += " and ";
				}
				params['FilterExpression'] += "contains(#features,:features)"
				params['ExpressionAttributeNames']["#features"] = "features";
				params['ExpressionAttributeValues'][":features"] = data.features;
			}
			//get by flatStatus
			if (data.flat_status) {
				if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
					params['FilterExpression'] = "";
					params['ExpressionAttributeValues'] = {};
					params['ExpressionAttributeNames'] = {};
				} else {
					params['FilterExpression'] += " and ";
				}
				params['FilterExpression'] += "#flat_status IN (:flat_status) "
				params['ExpressionAttributeValues'][":flat_status"] = (data.flat_status)
				params['ExpressionAttributeNames']["#flat_status"] = "flat_status";
			}
		}
		return new Promise((resolve, reject) => {
			params['Limit'] = offset;
			if (data.lastEvaluatedKeyflatId && data.lastEvaluatedKeyactive && data.lastEvaluatedKeytotalPrice) {
				try {
					params['ExclusiveStartKey'] = {
						active: data.lastEvaluatedKeyactive,
						flatId: data.lastEvaluatedKeyflatId,
						totalPrice: parseFloat(data.lastEvaluatedKeytotalPrice)
					};
				} catch (error) {
					reject("Invalid last evaluated keys");
					return;
				}
			}
			console.log(params, "scan");
			docClient.scan(params, function (err, data) {
				if (err) {
					reject(err);
				} else {
					console.log(data);
					var container = {};
					container['page'] = data.LastEvaluatedKey;
					container['data'] = data.Items;
					resolve(container); //getting successfully
				}
			});
		})
	}
}